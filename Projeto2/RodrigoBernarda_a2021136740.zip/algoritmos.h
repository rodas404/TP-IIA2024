#ifndef ALGORITMOS_H
#define ALGORITMOS_H

#include "utils.h"

int trepa_colinas(int sol[], ProblemData data, int n_iter);
void gera_vizinho(int s[], int ns[], ProblemData data);
void gera_vizinho2(int s[], int ns[], ProblemData data);


#endif // ALGORITMOS_H